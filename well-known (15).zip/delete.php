<?php
include __DIR__ . '/connection/db.php';  // Correct path

if (isset($_GET['id'])) {
    $warranty_id = intval($_GET['id']);

    $conn->begin_transaction();

    try {
        $stmt1 = $conn->prepare("DELETE FROM warranty_serials WHERE warranty_id = ?");
        $stmt1->bind_param("i", $warranty_id);
        $stmt1->execute();
        $stmt1->close();

        $stmt2 = $conn->prepare("DELETE FROM warranty WHERE id = ?");
        $stmt2->bind_param("i", $warranty_id);
        $stmt2->execute();

        if ($stmt2->affected_rows == 0) {
            throw new Exception("No warranty found with ID $warranty_id");
        }

        $stmt2->close();
        $conn->commit();

        header("Location: add.php?message=Warranty+Deleted+Successfully");
        exit();

    } catch (Exception $e) {
        $conn->rollback();
        echo 'Error deleting record: ' . $e->getMessage();
    }

} else {
    echo 'No warranty ID specified';
}

$conn->close();
?>
