<?php

$servername = "localhost";
$username = "svglk1_admin";
$password = "@3594HelloSVg";
$database = "svglk1_warranty";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
