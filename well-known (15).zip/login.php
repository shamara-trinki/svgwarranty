<?php
session_start();
include __DIR__ . '/connection/db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Save login info in session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: add.php");
        exit();
    } else {
        $error = "❌ Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Inter', sans-serif;
    }

    body,
    html {
        height: 100%;
    }

    .container {
        display: flex;
        height: 100vh;
    }

    /* Left side - Image/Welcome */
    .left-side {
        flex: 1;
        background: linear-gradient(135deg, #a6a6c0ff, #ffffffff);
        background-size: cover;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
    }

    .left-side h1 {
        font-size: 48px;
        font-weight: 700;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5);
    }

    /* Right side - Login Form */
    .right-side {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #0f0c97ff, #ffffffff);
    }

    .login-box {
        width: 550px;
        padding: 40px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    .login-box h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #333;
    }

    .input-group {
        margin-bottom: 20px;
    }

    .input-group input {
        width: 100%;
        padding: 12px 15px;
        border-radius: 8px;
        border: 1px solid #ddd;
        font-size: 16px;
        transition: border 0.3s;
    }

    .input-group input:focus {
        border-color: #6C63FF;
        outline: none;
    }

    button {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 8px;
        background: #6C63FF;
        color: white;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s;
    }

    button:hover {
        background: #574fd1;
    }

    .error {
        color: red;
        text-align: center;
        margin-bottom: 15px;
    }

    .register-link {
        text-align: center;
        margin-top: 15px;
        font-size: 14px;
        color: #555;
    }

    .register-link a {
        color: #6C63FF;
        text-decoration: none;
    }

    .register-link a:hover {
        text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .left-side,
        .right-side {
            flex: none;
            width: 100%;
            height: 50vh;
        }
    }
    </style>

</head>

<body>
    <div class="container">
        <div class="left-side">
            <h1>Welcome Back!</h1>
        </div>

        <div class="right-side">
            <div class="login-box">
                <h2>Login</h2>
                <?php if($error) echo "<p class='error'>$error</p>"; ?>
                <form method="POST">
                    <div class="input-group">
                        <input type="text" name="username" placeholder="Username" required>
                    </div>
                    <div class="input-group">
                        <input type="password" name="password" placeholder="Password" required>
                    </div>
                    <button type="submit">Login</button>
                </form>
                <div class="register-link">
                    Don't have an account? <a href="register">Register</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
