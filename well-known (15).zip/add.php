<!-- Header -->
<?php
session_start();
include 'header.php';
include __DIR__ . '/connection/db.php';  // Correct path


?>


<body>

    <div class="container-fluid mt-4">
        <!-- Navbar -->
        <?php include 'title.php';?>

        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm p-3 mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <!-- Header -->
                        <h4 class="mb-0 fw-semibold">📋 Warranty Details</h4>

                        <!-- Buttons Group -->
                        <div class="d-flex gap-2">
                            <a href="warranty.php" class="btn btn-primary btn-modern">
                                ➕ Add New Warranty
                            </a>
                            <a href="update.php" class="btn btn-primary btn-modern"><i class="fa fa-file"></i>
                                UpdateInfo
                            </a>
                            <a href="report.php" class="btn btn-primary btn-modern"><i class="fa fa-user"
                                    aria-hidden="true"></i> Dealer Report

                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Update Warranty Modal -->
        <div class="modal fade" id="updateModal" tabindex="-1">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content modern-modal">
                    <div class="modal-header">
                        <h5 class="modal-title">✏️ Update Warranty</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form id="updateForm" action="update_save.php" method="POST">
                        <div class="modal-body">
                            <input type="hidden" id="warranty_id" name="warranty_id">

                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Invoice No</label>
                                    <input type="text" id="invoice_no" name="invoice_no" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Invoice Date</label>
                                    <input type="date" id="invoice_date" name="invoice_date" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Dealer</label>
                                    <select id="dealer_id" name="dealer_id" class="form-select"></select>
                                </div>
                            </div>

                            <div class="row g-3 mt-1">

                                <div class="col-md-4">
                                    <label class="form-label">Customer</label>
                                    <select id="customer_id" name="customer_id" class="form-select"></select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Warranty Period</label>
                                    <select id="warranty_period" name="warranty_period" class="form-select">
                                        <option value="2">2 Years</option>
                                        <option value="5">5 Years</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Warranty For</label>

                                    <select id="warranty_for" name="warranty_for" class="form-select">
                                        <option value="TANK">Tank </option>
                                        <option value="HEATING">Heating element anode electrical parts</option>
                                    </select>
                                </div>
                            </div>



                            <div class="row g-3 mt-1">
                                <div class="col-md-4">
                                    <label class="form-label">Warranty Expiry Date</label>
                                    <input type="date" id="warranty_expiry_date" name="warranty_expiry_date"
                                        class="form-control">
                                </div>

                            </div>

                            <div class="serials-section mt-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="mb-0">📦 Item Serials</h6>
                                    <button type="button" id="addRow" class="btn btn-sm btn-outline-primary">+ Add
                                        Row</button>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered align-middle" id="itemsTable">
                                        <thead class="table-light text-center">
                                            <tr>
                                                <th>Item</th>
                                                <th>Quantity</th>
                                                <th>Serial No</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Filled by JS -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-gradient">💾 Save Changes</button>
                            <button type="button" class="btn btn-outline-secondary"
                                data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>




        <!-- Table -->
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm p-3">
                    <div class="table-responsive">
                        <table id="warrantyTable" class="table table-striped table-bordered nowrap align-middle"
                            style="width:100%">
                            <thead class="table-white text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Invoice No</th>
                                    <th>Invoice Date</th>
                                    <th>Dealer Name</th>
                                    <th>Customer Name</th>
                                    <th>Item Name</th>
                                    <th>Warranty <br>Period</th>
                                    <th>Warranty For</th>
                                    <th>Warranty <br>Expiry Date</th>
                                    <th>Qty</th>
                                    <th>Serial No</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                        $sql = "SELECT
                                    warranty.*,
                                    customer.cus_name,
                                    dealer.dealer_name,
                                    item.item_name,
                                    GROUP_CONCAT(warranty_serials.serial_no SEPARATOR ', ') AS serial_numbers
                                FROM warranty
                                LEFT JOIN warranty_serials ON warranty.id = warranty_serials.warranty_id
                                LEFT JOIN dealer ON warranty.dealer_id = dealer.id
                                LEFT JOIN customer ON warranty.customer_id = customer.id
                                LEFT JOIN item ON warranty.item_id = item.id
                                GROUP BY warranty.id";

                        $result = $conn->query($sql);
                        $count = 1;

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $expiryDate = $row['warranty_expiry_date'];
                                $today = date('Y-m-d');
                                $statusColor = ($expiryDate < $today) ? 'red' : 'green';
                                $statusText = ($expiryDate < $today) ? 'Expired' : 'Pending';

                                echo "<tr>";
                                echo "<th scope='row'>{$count}</th>";
                                echo "<td>" . htmlspecialchars($row['invoice_no']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['invoice_date']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['dealer_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['cus_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['item_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['warranty_period']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['warranty_for']) . "</td>";
                                echo "<td style='color: {$statusColor}; font-weight: bold;'>{$statusText} (" . htmlspecialchars($expiryDate) . ")</td>";
                                echo "<td>" . htmlspecialchars($row['qty']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['serial_numbers']) . "</td>";
                                echo "<td class='text-center'>
                                        <button class='btn btn-sm btn-primary updateBtn'
                                            data-id='" . htmlspecialchars($row['id']) . "'
                                            data-invoice_no='" . htmlspecialchars($row['invoice_no']) . "'
                                            data-invoice_date='" . htmlspecialchars($row['invoice_date']) . "'
                                            data-dealer_id='" . htmlspecialchars($row['dealer_id']) . "'
                                            data-customer_id='" . htmlspecialchars($row['customer_id']) . "'
                                            data-item_id='" . htmlspecialchars($row['item_id']) . "'
                                            data-warranty_period='" . htmlspecialchars($row['warranty_period']) . "'
                                            data-warranty_for='" . htmlspecialchars($row['warranty_for']) . "'
                                            data-warranty_expiry_date='" . htmlspecialchars($row['warranty_expiry_date']) . "'
                                            data-qty='" . htmlspecialchars($row['qty']) . "'
                                            data-serial_numbers='" . htmlspecialchars(json_encode(explode(',', $row['serial_numbers']))) . "'>
                                            <i class='fa fa-edit'></i>
                                        </button>
                                        <a href='delete.php?id=" . urlencode($row['id']) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'>
                                            <i class='fa fa-trash'></i>
                                        </a>
                                    </td>";
                                echo "</tr>";
                                $count++;
                            }
                        } else {
                            echo "<tr><td colspan='12' class='text-center'>No results found</td></tr>";
                        }
                        $conn->close();
                        ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <?php include 'footer.php';?>

    <script>
    $(document).ready(function() {
        $('#warrantyTable').DataTable({
            responsive: true,
            pageLength: 10,
            lengthMenu: [5, 10, 25, 50],
            columnDefs: [{
                className: "text-center",
                targets: "_all"
            }]
        });
    });


    let itemsList = [];

    // Load items from backend
    function loadItems() {
        $.getJSON('controller/get_item.php', function(data) {
            itemsList = data;
        });
    }
    loadItems();

    // Create item select
    function createItemSelect(selectedId = null) {
        let html = '<select name="item_id[]" class="form-select">';
        itemsList.forEach(function(item) {
            let sel = (item.id == selectedId) ? 'selected' : '';
            html += `<option value="${item.id}" ${sel}>${item.item_name}</option>`;
        });
        html += '</select>';
        return html;
    }

    // Open Update Modal
    $(document).on("click", ".updateBtn", function() {
        let id = $(this).data("id");
        let invoice_no = $(this).data("invoice_no");
        let invoice_date = $(this).data("invoice_date");
        let dealer_id = $(this).data("dealer_id");
        let customer_id = $(this).data("customer_id");
        let warranty_period = $(this).data("warranty_period");
        let warranty_for = $(this).data("warranty_for");
        let warranty_expiry_date = $(this).data("warranty_expiry_date");
        let serials = $(this).data("serial_numbers"); // JSON array

        $("#warranty_id").val(id);
        $("#invoice_no").val(invoice_no);
        $("#invoice_date").val(invoice_date);
        $("#dealer_id").val(dealer_id);
        $("#customer_id").val(customer_id);
        $("#warranty_period").val(warranty_period);
        $("#warranty_for").val(warranty_for);
        $("#warranty_expiry_date").val(warranty_expiry_date);

        let tbody = $("#itemsTable tbody");
        tbody.empty();

        if (serials && Array.isArray(serials)) {
            serials.forEach(sn => {
                let row = `<tr>
                <td>${createItemSelect()}</td>
                <td><input type="number" name="quantity[]" class="form-control" value="1" readonly></td>
                <td><input type="text" name="serial_id[]" class="form-control" value="${sn.trim()}"></td>
                <td class="text-center"><button type="button" class="btn btn-danger btn-sm removeRow">❌</button></td>
            </tr>`;
                tbody.append(row);
            });
        }

        $("#updateModal").modal("show");
    });

    // Add new row
    $(document).on("click", "#addRow", function() {
        let newRow = `<tr>
        <td>${createItemSelect()}</td>
        <td><input type="number" name="quantity[]" class="form-control" value="1" readonly></td>
        <td><input type="text" name="serial_id[]" class="form-control" placeholder="Enter Serial No"></td>
        <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger removeRow">❌</button></td>
    </tr>`;
        $("#itemsTable tbody").append(newRow);
    });

    // Remove row
    $(document).on("click", ".removeRow", function() {
        $(this).closest("tr").remove();
    });

    // AJAX form submit
    $('#updateForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'controller/updateController.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    alert('✅ ' + res.message);
                    location.reload();
                } else {
                    alert('❌ Update failed: ' + res.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', status, error);
                alert('Error updating warranty. Check console.');
            }
        });
    });
    </script>

</body>

</html>
