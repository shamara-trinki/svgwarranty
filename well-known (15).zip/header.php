   <?php    // Protect page
    if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
    }?>


   <!DOCTYPE html>
   <html>

   <meta http-equiv="content-type" content="text/html;charset=UTF-8" />

   <head>
       <title>Warranty Tracker System</title>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
       <!-- custom-theme -->
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
       <meta name="keywords" content="" />
       <script type="application/x-javascript">
       addEventListener("load", function() {
           setTimeout(hideURLbar, 0);
       }, false);

       function hideURLbar() {
           window.scrollTo(0, 1);
       }
       </script>
       <!-- //custom-theme -->
       <!-- js -->
       <script src="js/jquery.min.js"></script>
       <!-- //js -->
       <!-- font-awesome-icons -->
       <link href="css/font-awesome.css" rel="stylesheet">
       <!-- bootstrap -->
       <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">


       <link href="datatable/datatables.min.css" rel="stylesheet">
       <link href="datatable/datatables.css" rel="stylesheet">
       <link href="datatable/buttons.dataTables.css" rel="stylesheet">
       <link href="datatable/dataTables.dataTables.css" rel="stylesheet">




       <!-- //font-awesome-icons -->
       <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
       <link
           href="http://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext"
           rel="stylesheet">
   </head>

   <body>

       <script src='../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'>
       </script>
       <script src="../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
       <script src="js/jquery.validate.min.js"></script>
       <script src="js/jquery.formtowizard.js"></script>

       <script src="datatable/datatables.min.js"></script>
       <script src="datatable/datatables.js"></script>
       <script src="datatable/dataTables.buttons.js"></script>
       <script src="datatable/buttons.dataTables.js"></script>
       <script src="datatable/jszip.min.js"></script>
       <script src="datatable/pdfmake.min.js"></script>
       <script src="datatable/buttons.html5.min.js"></script>
       <script src="datatable/buttons.print.min.js"></script>
       <script src="datatable/vfs_fonts.js"></script>

       <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
       <script>
       (function() {
           if (typeof _bsa !== 'undefined' && _bsa) {
               // format, zoneKey, segment:value, options
               _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
           }
       })();
       </script>
       <script>
       (function() {
           if (typeof _bsa !== 'undefined' && _bsa) {
               // format, zoneKey, segment:value, options
               _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
           }
       })();
       </script>
       <script>
       (function() {
           if (typeof _bsa !== 'undefined' && _bsa) {
               // format, zoneKey, segment:value, options
               _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
           }
       })();
       </script>
       <script>
       (function(v, d, o, ai) {
           ai = d.createElement("script");
           ai.defer = true;
           ai.async = true;
           ai.src = v.location.protocol + o;
           d.head.appendChild(ai);
       })(window, document, "../../../../../../vdo.ai/core/w3layouts/vdo.ai.js");
       </script>
       <!-- Global site tag (gtag.js) - Google Analytics -->
       <script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
       <script>
       window.dataLayer = window.dataLayer || [];

       function gtag() {
           dataLayer.push(arguments);
       }
       gtag('js', new Date());

       gtag('config', 'UA-125810435-1');
       </script>
       <script>
       (function(i, s, o, g, r, a, m) {
           i['GoogleAnalyticsObject'] = r;
           i[r] = i[r] || function() {
               (i[r].q = i[r].q || []).push(arguments)
           }, i[r].l = 1 * new Date();
           a = s.createElement(o),
               m = s.getElementsByTagName(o)[0];
           a.async = 1;
           a.src = g;
           m.parentNode.insertBefore(a, m)
       })(window, document, 'script', '../../../../../../www.google-analytics.com/analytics.js', 'ga');
       ga('create', 'UA-30027142-1', 'w3layouts.com');
       ga('send', 'pageview');
       </script>
