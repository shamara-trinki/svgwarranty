<script>
new DataTable('#example');

window.addEventListener('load', function() {

    // Bootstrap alert show/hide
    function showAlert(message, type = 'success') {
        const alertBox = document.getElementById('alertBox');
        const alertMessage = document.getElementById('alertMessage');

        alertBox.className = `alert alert-${type} alert-dismissible fade show`;
        alertMessage.textContent = message;
        alertBox.classList.remove('d-none');


    }


    // Save customer via AJAX
    // $('#saveCustomerBtn').on('click', function() {
    //     const name = $('#customer_name').val().trim();

    //     if (!name) {
    //         showAlert("Please enter customer name", "warning");
    //         return;
    //     }

    //     $.post("controller/customerController.php", {
    //         customer_name: name
    //     }, function(response) {
    //         if (response.success) {
    //             $('#customer_id').append(
    //                 `<option value="${response.customer_id}" selected>${response.customer_name}</option>`
    //             );
    //             $('#customerModel').modal('hide');
    //             $('#customer_name').val('');
    //             showAlert(response.message, 'success');
    //         } else {
    //             showAlert(response.message, 'danger');
    //         }
    //     }, 'json');
    // });
    $(document).ready(function() {
        $('#saveCustomerBtn').on('click', function(e) {
            e.preventDefault();

            const customer_name = $('#customer_name').val().trim();
            const mobile_no = $('#mobile_no').val().trim();
            const formData = {
                customer_name: customer_name,
                address_line1: $('#address_line1').val(),
                address_line2: $('#address_line2').val(),
                mobile_no: mobile_no
            };

            // Validation
            if (!customer_name) {
                alert("Please enter customer name!");
                return;
            }
            if (!/^\d{10}$/.test(mobile_no)) {
                alert("Please enter a valid 10-digit mobile number!");
                return;
            }

            $.ajax({
                url: 'controller/customerController.php',
                method: 'POST',
                data: formData,
                dataType: 'json', // important!
                success: function(response) {
                    if (response.success) {
                        // Add new customer to dropdown
                        $('#customer_id').append(
                            `<option value="${response.customer_id}" selected>${response.customer_name}</option>`
                        );

                        // Hide Bootstrap 5 modal
                        const modalEl = document.getElementById('customerModal');
                        const myModal = bootstrap.Modal.getInstance(modalEl) ||
                            new bootstrap.Modal(modalEl);
                        myModal.hide();

                        // Clear input fields
                        $('#customer_name, #address_line1, #address_line2, #mobile_no')
                            .val('');

                        alert("Customer added successfully! ✅");
                    } else {
                        alert("❌ " + (response.message || "Something went wrong!"));
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    $('#alertBox')
                        .removeClass('d-none alert-success')
                        .addClass('alert-danger');
                    $('#alertMessage').text('Server error!');
                }
            });
        });
    });




    // Save dealer via AJAX
    $('#saveDealerBtn').on('click', function() {
        const name = $('#dealer_name').val().trim();

        if (!name) {
            showAlert("Please Enter Dealer name", "warning");
            return;
        }

        $.post("controller/dealerController.php", {
            dealer_name: name
        }, function(response) {
            if (response.success) {
                // Add new dealer to dropdown
                $('#dealer_id').append(
                    `<option value="${response.dealer_id}" selected>${response.dealer_name}</option>`
                );

                // ✅ Bootstrap 5 modal hide
                const modalEl = document.getElementById('dealerModal');
                const myModal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(
                    modalEl);
                myModal.hide();

                // Clear input
                $('#dealer_name').val('');

                alert("Dealer added successfully! ✅");
            } else {
                alert("❌ Something went wrong!");
            }
        }, 'json');
    });

    // Save item via AJAX
    // $('#saveItemBtn').on('click', function() {
    //     const name = $('#item_name').val().trim();

    //     if (!name) {
    //         alert("Please enter Item Name");
    //         return;
    //     }

    //     $.post("controller/itemController.php", {
    //         item_name: name
    //     }, function(response) {
    //         if (response.success) {
    //             // ✅ Refresh items
    //             loadItems();

    //             // ✅ Repopulate all item selects with updated list
    //             setTimeout(() => {
    //                 $('.item-select').each(function() {
    //                     populateItemSelect($(this));
    //                 });

    //                 // Optionally auto-select the newly added item
    //                 $('.item-select:last').val(response.item_id);
    //             }, 300);

    //             $('#itemModal').modal('hide');
    //             $('#item_name').val('');
    //         } else {
    //             alert(response.message || "Failed to save item");
    //         }
    //     }, 'json');
    // });



});


document.addEventListener("DOMContentLoaded", function() {
    // Populate customer dropdown
    fetch("controller/get_customers.php")
        .then(res => res.json())
        .then(customers => {
            const select = document.getElementById("customer_id");
            customers.forEach(customer => {
                const opt = document.createElement("option");
                opt.value = customer.id;
                opt.textContent = customer.cus_name;
                select.appendChild(opt);
            });
        })
        .catch(err => console.error("Failed to load customers", err));

    // dealer dropdown
    fetch("controller/get_dealer.php")
        .then(res => res.json())
        .then(dealers => {
            const select = document.getElementById("dealer_id");
            dealers.forEach(dealer => {
                const opt = document.createElement("option");
                opt.value = dealer.id;
                opt.textContent = dealer.dealer_name;
                select.appendChild(opt);
            });
        })
        .catch(err => console.error("Failed to load dealer", err));

    // item dropdown
    fetch("controller/get_item.php")
        .then(res => res.json())
        .then(items => {
            const select = document.getElementById("item_id");
            select.value = existingItemId; // e.g., from your DB



            items.forEach(item => {
                const opt = document.createElement("option");
                opt.value = item.id;
                opt.textContent = item.item_name;
                select.appendChild(opt);
            });
        })
        .catch(err => console.error("Failed to load items", err));

    // Submit form handler
    document.getElementById("SignupForm").addEventListener("submit", function(e) {
        e.preventDefault();
        const formData = new FormData(this);

        fetch("controller/warrentyController.php", {
                method: "POST",
                body: formData
            })
            .then(res => res.json()) // this will fail if PHP outputs HTML
            .then(data => {
                if (data.success) {
                    alert("✅" + data.message);
                    this.reset();
                    localStorage.removeItem('itemsTable'); // clear saved table
                    location.reload();
                } else {
                    alert("❌ " + data.message);
                }
            })
            .catch(err => {
                console.error(err);
                alert("❌ Error occurred while submitting.");
            });
    });


});



//update Function
$(document).on('click', '.updateBtn', function() {
    // Fill modal inputs with data attributes from the clicked button
    $('#update_id').val($(this).data('id'));
    $('#update_invoice_no').val($(this).data('invoice_no'));
    $('#update_invoice_date').val($(this).data('invoice_date'));
    $('#update_dealer_id').val($(this).data('dealer_id')).change();
    $('#update_customer_id').val($(this).data('customer_id')).change();
    $('#update_item_id').val($(this).data('item_id')).change();
    $('#update_warranty_period').val($(this).data('warranty_period'));
    $('#update_warranty_expiry_date').val($(this).data('warranty_expiry_date'));
    $('#update_qty').val($(this).data('qty'));

    // Parse serial numbers from data attribute (assumed to be JSON string)
    let serialsRaw = $(this).attr('data-serial_numbers') || '[]';
    let serialArray = [];
    try {
        serialArray = JSON.parse(serialsRaw);
    } catch {
        serialArray = [];
    }

    // Render serial input fields according to qty and fill with existing serials
    function renderSerialInputs(qty) {
        const container = $('#serial-number-container-update');
        container.empty();

        for (let i = 0; i < qty; i++) {
            let value = serialArray[i] || '';
            let input = $(`
                <input type="text" name="serial_id[]" class="form-control mb-2" placeholder="Serial Number ${i + 1}" required />
            `).val(value);
            container.append(input);
        }
    }

    let qtyVal = parseInt($('#update_qty').val()) || 1;
    renderSerialInputs(qtyVal);

    // Update serial inputs dynamically if qty changes
    $('#update_qty').off('input').on('input', function() {
        let newQty = parseInt($(this).val());
        if (!newQty || newQty < 1) newQty = 1;
        renderSerialInputs(newQty);
    });
});

$('#updateForm').on('submit', function(e) {
    e.preventDefault();

    $.ajax({
        url: 'controller/updateController.php',
        type: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            // Try parsing response safely
            let result;
            try {
                result = typeof response === 'object' ? response : JSON.parse(response);
            } catch (e) {
                // console.error('JSON parse error:', e, response);
                alert('Unexpected server response.');
                return;
            }

            // console.log('Parsed Result:', result);

            if (result.success) {
                alert("✅ " + 'Record updated successfully');
                location.reload(); // Optionally change to a smoother update if needed
            } else {
                alert('Update failed: ' + (result.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', status, error);
            alert('Error updating. Please try again.');
        }
    });
});
</script>
