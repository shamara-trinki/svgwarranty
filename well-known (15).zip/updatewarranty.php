<?php
session_start();

include 'connection/db.php';
 include 'header.php';


// Check if we are editing
$record = [];
$items = [];

if (isset($_GET['id'])) {
$warranty_id = intval($_GET['id']);

// Fetch warranty record
$sql = "SELECT * FROM warranties WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $warranty_id);
$stmt->execute();
$result = $stmt->get_result();
$record = $result->fetch_assoc();

// Fetch warranty items
$sql_items = "SELECT * FROM warranty_items WHERE warranty_id = ?";
$stmt2 = $conn->prepare($sql_items);
$stmt2->bind_param("i", $warranty_id);
$stmt2->execute();
$items = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>
<!-- Header -->

<form id="updateForm" class="agile_form" method="post">
    <input type="hidden" name="warranty_id" value="<?= $record['id'] ?? '' ?>">

    <!-- Invoice Details -->
    <div class="card mb-4">
        <div class="card-header">📑 Invoice Details</div>
        <div class="card-body row g-3">
            <div class="col-md-4">
                <label class="form-label">Invoice No</label>
                <input id="invoice_no" type="text" name="invoice_no" class="form-control"
                    value="<?= htmlspecialchars($record['invoice_no'] ?? '') ?>" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Invoice Date</label>
                <input id="invoice_date" type="date" name="invoice_date" class="form-control"
                    value="<?= htmlspecialchars($record['invoice_date'] ?? '') ?>" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Dealer</label>
                <div class="input-group">
                    <select id="dealer_id" name="dealer_id" class="form-select" style="flex: 2;">
                        <option value="">Select Dealer</option>
                        <?php
                        $dealers = $conn->query("SELECT * FROM dealers");
                        while ($d = $dealers->fetch_assoc()) {
                            $selected = ($record['dealer_id'] ?? '') == $d['id'] ? 'selected' : '';
                            echo "<option value='{$d['id']}' $selected>{$d['dealer_name']}</option>";
                        }
                        ?>
                    </select>
                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#dealerModal">+ Add</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Item Details -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>Item Details</span>
            <button type="button" class="btn btn-success btn-sm" id="addRow">+ Add Item</button>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-hover align-middle" id="itemsTable">
                <thead class="table-light">
                    <tr>
                        <th>Item</th>
                        <th style="width: 120px;">Quantity</th>
                        <th style="width: 300px;">Serial Nos</th>
                        <th style="width: 80px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($items)) : ?>
                    <?php foreach ($items as $it): ?>
                    <tr>
                        <td>
                            <select name="item_id[]" class="form-select">
                                <?php
                                        $allItems = $conn->query("SELECT * FROM items");
                                        while ($i = $allItems->fetch_assoc()) {
                                            $sel = ($it['item_id'] == $i['id']) ? 'selected' : '';
                                            echo "<option value='{$i['id']}' $sel>{$i['item_name']}</option>";
                                        }
                                        ?>
                            </select>
                        </td>
                        <td><input type="number" name="quantity[]" class="form-control" value="<?= $it['quantity'] ?>">
                        </td>
                        <td><input type="text" name="serial_no[]" class="form-control" value="<?= $it['serial_no'] ?>">
                        </td>
                        <td><button type="button" class="btn btn-danger btn-sm removeRow">❌</button></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Customer Section -->
    <div class="card mb-4">
        <div class="card-header">👤 Customer Details</div>
        <div class="card-body">
            <div class="input-group">
                <select id="customer_id" name="customer_id" class="form-select" style="flex: 2;">
                    <option value="">Select Customer</option>
                    <?php
                    $customers = $conn->query("SELECT * FROM customers");
                    while ($c = $customers->fetch_assoc()) {
                        $selected = ($record['customer_id'] ?? '') == $c['id'] ? 'selected' : '';
                        echo "<option value='{$c['id']}' $selected>{$c['customer_name']}</option>";
                    }
                    ?>
                </select>
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                    data-bs-target="#customerModal">+ Add Customer</button>
            </div>
        </div>
    </div>

    <!-- Warranty -->
    <div class="card mb-4">
        <div class="card-header">🛡️ Warranty Details</div>
        <div class="card-body row g-3">
            <div class="col-md-4">
                <label class="form-label">Warranty Period</label>
                <select name="warranty_period" id="warranty_period" class="form-select" required>
                    <option value="2" <?= ($record['warranty_period'] ?? '') == '2' ? 'selected' : '' ?>>2 Years
                    </option>
                    <option value="5" <?= ($record['warranty_period'] ?? '') == '5' ? 'selected' : '' ?>>5 Years
                    </option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Warranty For</label>
                <select name="warranty_for" id="warranty_for" class="form-select" required>
                    <option value="TANK" <?= ($record['warranty_for'] ?? '') == 'TANK' ? 'selected' : '' ?>>Tank
                    </option>
                    <option value="HEATING" <?= ($record['warranty_for'] ?? '') == 'HEATING' ? 'selected' : '' ?>>
                        Heating element anode electrical parts</option>
                </select>
            </div>
            <div class="col-md-4">
                <?php
                $rawDate = $record['warranty_expiry_date'] ?? '';
                $formattedDate = '';
                if ($rawDate) {
                    $date = date_create($rawDate);
                    if ($date) {
                        $formattedDate = date_format($date, 'Y-m-d');
                    }
                }
                ?>
                <label class="form-label">Warranty Expiry Date</label>
                <input type="date" name="warranty_expiry_date" class="form-control" value="<?= $formattedDate ?>">
            </div>
        </div>
    </div>

    <div class="text-end pb-5">
        <?php if (!empty($record)): ?>
        <button type="submit" class="btn btn-warning px-5">Update Warranty</button>
        <?php else: ?>
        <button type="submit" class="btn btn-primary px-5">Save Warranty</button>
        <?php endif; ?>
    </div>
</form>

</div>
