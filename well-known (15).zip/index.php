<?php


include __DIR__ . '/connection/db.php';


include 'headerindex.php';
?>

<body>
    <div class="container-fluid">
        <div class="row pt-20">
            <div class="col-xl-12 pt-10">

                <div class="card-header">

                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group agileits_w3layouts_form w3_agileits_margin">
                                    <label>Tracking Serial No.</label>
                                    <div class="wthree_input">
                                        <i class="fa fa-key" aria-hidden="true"></i>
                                        <input id="tracking_no" type="text" name="tracking_no" class="form-control"
                                            required />
                                    </div>
                                </div>
                                <button type="button" class="btn btn-primary" id="SearchTrackingNo">Search</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <table class="table">
                                    <thead class="table-white">
                                        <tr>
                                            <th>#</th>
                                            <th>Invoice No</th>
                                            <th>Invoice Date</th>
                                            <th>Dealer</th>
                                            <th>Customer</th>
                                            <th>Item</th>
                                            <th>Warranty Period</th>
                                            <th>Warranty For</th>
                                            <th>Warranty Expiry</th>
                                            <th>Warranty Expiry Status</th>
                                            <th>Qty</th>
                                            <th>Serial No</th>
                                        </tr>
                                    </thead>
                                    <tbody id="warrantyTableBody">
                                        <!-- AJAX data will go here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</body>
<?php include 'footer.php'; ?>
<script>
$('#SearchTrackingNo').on('click', function() {
    var serial = $('#tracking_no').val();
    if (serial.trim() === "") {
        alert("Please enter a serial number.");
        return;
    }

    $.ajax({
        url: 'controller/searchController.php',
        type: 'POST',
        data: {
            serial_no: serial
        },
        success: function(response) {
            $('#warrantyTableBody').html(response);
        },
        error: function() {
            alert("Error fetching data.");
        }
    });
});
</script>

</html>
