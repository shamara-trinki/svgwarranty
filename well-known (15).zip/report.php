<?php
session_start();

include 'header.php';
include 'connection/db.php';


if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
    echo "<script>
    alert('$message');
    if (window.history.replaceState) {
        // Remove the query string without reloading
        window.history.replaceState(null, null, window.location.pathname);
    }
</script>";
}
?>

<body>


    <div class="container-fluid">
        <div class="row pt-20">
            <div class="col-xl-12 pt-10">

                <div class="card-header">
                    <?php include 'title.php';?>
                </div>

                <div class="card">
                    <div class="card-body">
                        <!-- Button -->
                        <div class="col text-right">


                            <form action="" method="GET">
                                <div class="row justify-content-end align-items-end">

                                    <!-- Dealer dropdown with label after select -->
                                    <div class="col-md-3">
                                        <div class="inline-label-group">
                                            <label for="dealer">Dealer</label>
                                            <select name="dealer" id="dealer" class="form-control"
                                                style="font-weight:bold; color:black;">
                                                <option value="">Select Dealer</option>
                                                <?php
                                                    $result = $conn->query("SELECT id, dealer_name FROM dealer");
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo '<option value="' . $row['id'] . '">' . $row['dealer_name'] . '</option>';
                                                    }
                                                    ?>
                                            </select>

                                        </div>
                                    </div>

                                    <!-- Month dropdown with label after select -->
                                    <div class="col-md-3">
                                        <div class="inline-label-group">
                                            <label for="start_date">Start Date</label>
                                            <input type="date" name="start_date" id="start_date" class="form-control"
                                                style="font-weight:bold; color:black;">
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="inline-label-group">
                                            <label for="end_date">End Date</label>
                                            <input type="date" name="end_date" id="end_date" class="form-control"
                                                style="font-weight:bold; color:black;">
                                        </div>
                                    </div>

                                    <!-- Search button -->
                                    <div class="col-auto">
                                        <button type="submit" class="btn btn-primary"
                                            id="searchDealerWise">Search</button>
                                    </div>
                                </div>
                            </form>


                        </div>


                        <!-- Table -->
                        <div class="col" style="margin:20px;">
                            <div class="card">
                                <div class="card-body">
                                    <table id="example" class="table table-striped table-bordered ">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Invoice No</th>
                                                <th>Invoice Date</th>
                                                <th>Customer Name</th>
                                                <th>Item Name</th>
                                                <th>Warranty Period</th>
                                                <th>Warranty For</th>
                                                <th>Warranty Expiry Date</th>
                                                <th>Qty</th>
                                                <th>Serial No</th>

                                            </tr>
                                        </thead>
                                        <tbody id="warrantyTableDealerBody">

                                        </tbody>

                                    </table>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>






</body>
<?php include 'component/js.php';?>
<script>

</script>



</html>
