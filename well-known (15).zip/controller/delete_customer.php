<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $customer_id = intval($_POST['id']);

    
    $check = $conn->prepare("SELECT COUNT(*) FROM warranty WHERE customer_id = ?");
    $check->bind_param("i", $customer_id);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->close();

    if ($count > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Customer cannot be deleted because it is used in warranty records.'
        ]);
    } else {

        $stmt = $conn->prepare("DELETE FROM customer WHERE id=?");
        $stmt->bind_param("i", $customer_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Customer deleted successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }

        $stmt->close();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();
