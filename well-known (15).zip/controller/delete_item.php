<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $item_id = intval($_POST['id']);

    // Check if item is used in warranty_serials
    $check = $conn->prepare("SELECT COUNT(*) FROM warranty WHERE item_id = ?");
    $check->bind_param("i", $item_id);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->close();

    if ($count > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Item cannot be deleted because it is used in warranty records.'
        ]);
    } else {
        // Safe to delete
        $stmt = $conn->prepare("DELETE FROM item WHERE id=?");
        $stmt->bind_param("i", $item_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Item deleted successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }

        $stmt->close();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();