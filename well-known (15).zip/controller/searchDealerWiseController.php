<?php
include __DIR__ . '/../connection/db.php';

$start_date = $_POST['start_date'] ?? '';
$end_date   = $_POST['end_date'] ?? '';
$dealer     = $_POST['dealer'] ?? '';

if (!$start_date || !$end_date) {
    echo "<tr><td colspan='12' class='text-center'>Invalid date range.</td></tr>";
    exit;
}

$sql = "SELECT w.*, d.dealer_name, c.cus_name, i.item_name,
        GROUP_CONCAT(ws.serial_no SEPARATOR ', ') AS serial_numbers
        FROM warranty w
        LEFT JOIN dealer d ON w.dealer_id = d.id
        LEFT JOIN customer c ON w.customer_id = c.id
        LEFT JOIN item i ON w.item_id = i.id
        LEFT JOIN warranty_serials ws ON w.id = ws.warranty_id
        WHERE DATE(w.invoice_date) BETWEEN ? AND ?";

$params = [$start_date, $end_date];

// Add dealer filter if selected
if ($dealer) {
    $sql .= " AND w.dealer_id = ?";
    $params[] = $dealer;
}

$sql .= " GROUP BY w.id ORDER BY w.invoice_date DESC";

$stmt = $conn->prepare($sql);

if ($dealer) {
    $stmt->bind_param("ssi", $params[0], $params[1], $params[2]);
} else {
    $stmt->bind_param("ss", $params[0], $params[1]);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $count = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$count}</td>";
        echo "<td>".htmlspecialchars($row['invoice_no'])."</td>";
        echo "<td>".htmlspecialchars($row['invoice_date'])."</td>";
        echo "<td>".htmlspecialchars($row['cus_name'])."</td>";
        echo "<td>".htmlspecialchars($row['item_name'])."</td>";
        echo "<td>".htmlspecialchars($row['warranty_period'])."</td>";
        echo "<td>".htmlspecialchars($row['warranty_for'])."</td>";
        echo "<td>".htmlspecialchars($row['warranty_expiry_date'])."</td>";
        echo "<td>".htmlspecialchars($row['qty'])."</td>";
        echo "<td>".htmlspecialchars($row['serial_numbers'])."</td>";
        echo "</tr>";
        $count++;
    }
} else {
    echo "<tr><td colspan='12' class='text-center'>No records found.</td></tr>";
}

$stmt->close();
$conn->close();
