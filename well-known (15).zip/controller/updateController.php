<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');

include __DIR__ . '/../connection/db.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$id = $_POST['warranty_id'] ?? null;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Invalid record ID.']);
    exit;
}

// Sanitize inputs
$invoice_no = $_POST['invoice_no'] ?? '';
$invoice_date = $_POST['invoice_date'] ?? '';
$dealer_id = (int) ($_POST['dealer_id'] ?? 0);
$customer_id = (int) ($_POST['customer_id'] ?? 0);
$item_ids = $_POST['item_id'] ?? [];           // array of items
$quantities = $_POST['quantity'] ?? [];        // array of quantities
$serial_nos = $_POST['serial_id'] ?? [];       // array of serial numbers
$warranty_period = (int) ($_POST['warranty_period'] ?? 0);
$warranty_for = $_POST['warranty_for'] ?? '';
$warranty_expiry_date = $_POST['warranty_expiry_date'] ?? '';

try {
    $conn->begin_transaction();

    // Update main warranty record (first row)
    $stmt = $conn->prepare("UPDATE warranty SET invoice_no=?, invoice_date=?, dealer_id=?, customer_id=?, warranty_period=?, warranty_for=?, warranty_expiry_date=?, qty=?, item_id=? WHERE id=?");
    $firstQty = $quantities[0] ?? 1;
    $firstItem = $item_ids[0] ?? 0;
    $stmt->bind_param("ssiiissiii", $invoice_no, $invoice_date, $dealer_id, $customer_id, $warranty_period, $warranty_for, $warranty_expiry_date, $firstQty, $firstItem, $id);
    $stmt->execute();
    $stmt->close();

    // Delete old serials
    $stmtDel = $conn->prepare("DELETE FROM warranty_serials WHERE warranty_id=?");
    $stmtDel->bind_param("i", $id);
    $stmtDel->execute();
    $stmtDel->close();

    // Insert new serials
    $stmt2 = $conn->prepare("INSERT INTO warranty_serials (warranty_id, serial_no) VALUES (?, ?)");
    foreach ($serial_nos as $sn) {
        $sn = trim($sn);
        if ($sn !== '') {
            $stmt2->bind_param("is", $id, $sn);
            $stmt2->execute();
        }
    }
    $stmt2->close();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Warranty updated successfully.']);

} catch (mysqli_sql_exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Update failed: ' . $e->getMessage()]);
}
?>
