<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_name'])) {
    $item_name = trim($_POST['item_name']);
    $item_id = isset($_POST['id']) ? intval($_POST['id']) : null;

    if ($item_name === "") {
        echo json_encode(['success' => false, 'message' => 'Item name is required.']);
        exit;
    }

    if ($item_id) {
        // Update
        $stmt = $conn->prepare("UPDATE item SET item_name = ? WHERE id = ?");
        $stmt->bind_param("si", $item_name, $item_id);
        $msg = "Item updated successfully!";
    } else {
        // Add
        $stmt = $conn->prepare("INSERT INTO item (item_name) VALUES (?)");
        $stmt->bind_param("s", $item_name);
        $msg = "Item added successfully!";
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'item_id' => $stmt->insert_id ?: $item_id, 'item_name' => $item_name, 'message' => $msg]);
    } else {
        echo json_encode(['success' => false, 'message' => $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();
?>