<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dealer_name'])) {
    $dealer_name = trim($_POST['dealer_name']);
    $dealer_id = isset($_POST['id']) ? intval($_POST['id']) : null;

    if ($dealer_name === "") {
        echo json_encode(['success' => false, 'message' => 'Dealer name is required.']);
        exit;
    }

    if ($dealer_id) {
        // Update existing dealer
        $stmt = $conn->prepare("UPDATE dealer SET dealer_name = ? WHERE id = ?");
        $stmt->bind_param("si", $dealer_name, $dealer_id);

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'dealer_id' => $dealer_id,
                'dealer_name' => $dealer_name,
                'message' => 'Dealer updated successfully!'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }
    } else {
        // Add new dealer
        $stmt = $conn->prepare("INSERT INTO dealer (dealer_name) VALUES (?)");
        $stmt->bind_param("s", $dealer_name);

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'dealer_id' => $stmt->insert_id,
                'dealer_name' => $dealer_name,
                'message' => 'Dealer added successfully!'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();
?>
