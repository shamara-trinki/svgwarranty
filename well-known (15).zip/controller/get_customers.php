<?php

// Fixed include path
include __DIR__ . '/../connection/db.php';

$result = $conn->query("SELECT id, cus_name FROM customer");
$customers = [];

while ($row = $result->fetch_assoc()) {
    $customers[] = $row;
}

header('Content-Type: application/json');
echo json_encode($customers);

$conn->close();

?>