<?php

include __DIR__ . '/../connection/db.php';

$result = $conn->query("SELECT id, item_name FROM item");
$item = [];

while ($row = $result->fetch_assoc()) {
    $item[] = $row;
}

header('Content-Type: application/json');
echo json_encode($item);

$conn->close();

?>