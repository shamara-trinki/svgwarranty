<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

$customer_id = $_POST['customer_id'] ?? ''; // optional
$customer_name = $_POST['customer_name'] ?? '';
$address_line1 = $_POST['address_line1'] ?? '';
$address_line2 = $_POST['address_line2'] ?? '';
$mobile_no = $_POST['mobile_no'] ?? '';

if (empty($customer_name)) {
    echo json_encode(['success' => false, 'message' => 'Customer Name is required']);
    exit;
}

if (!empty($customer_id)) {
    // Update existing customer
    $stmt = $conn->prepare("UPDATE customer SET cus_name = ?, address_line1 = ?, address_line2 = ?, mobile_no = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $customer_name, $address_line1, $address_line2, $mobile_no, $customer_id);
    $action = 'updated';
} else {
    // Insert new customer
    $stmt = $conn->prepare("INSERT INTO customer (cus_name, address_line1, address_line2, mobile_no) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $customer_name, $address_line1, $address_line2, $mobile_no);
    $action = 'added';
}

if ($stmt->execute()) {
    $id = !empty($customer_id) ? $customer_id : $conn->insert_id;
    echo json_encode([
        'success' => true,
        'customer_id' => $id,
        'customer_name' => $customer_name,
        'message' => "Customer $action successfully"
    ]);
} else {
    echo json_encode(['success' => false, 'message' => $stmt->error]);
}

$stmt->close();
$conn->close();
?>