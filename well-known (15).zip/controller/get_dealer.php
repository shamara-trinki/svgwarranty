<?php
include __DIR__ . '/../connection/db.php';

$result = $conn->query("SELECT id, dealer_name FROM dealer");
$dealers = [];

while ($row = $result->fetch_assoc()) {
    $dealers[] = $row;
}

header('Content-Type: application/json');
echo json_encode($dealers);

$conn->close();
?>
