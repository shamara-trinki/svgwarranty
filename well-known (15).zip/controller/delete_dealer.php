<?php
header('Content-Type: application/json');
include __DIR__ . '/../connection/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $dealer_id = intval($_POST['id']);

    // Check if dealer is used in warranty
    $check = $conn->prepare("SELECT COUNT(*) FROM warranty WHERE dealer_id = ?");
    $check->bind_param("i", $dealer_id);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->close();

    if ($count > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Dealer cannot be deleted because it is used in warranty records.'
        ]);
    } else {
        // Safe to delete
        $stmt = $conn->prepare("DELETE FROM dealer WHERE id=?");
        $stmt->bind_param("i", $dealer_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Dealer deleted successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }

        $stmt->close();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();