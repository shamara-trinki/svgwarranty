<?php
include __DIR__ . '/../connection/db.php';

$serial_no = $_POST['serial_no'];

$sql = "SELECT
            warranty.*,
            customer.cus_name,
            dealer.dealer_name,
            item.item_name,
            warranty_serials.serial_no
        FROM warranty_serials
        INNER JOIN warranty ON warranty.id = warranty_serials.warranty_id
        LEFT JOIN customer ON warranty.customer_id = customer.id
        LEFT JOIN dealer ON warranty.dealer_id = dealer.id
        LEFT JOIN item ON warranty.item_id = item.id
        WHERE warranty_serials.serial_no = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $serial_no);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $count = 1;

    // define mapping once
    $warranty_map = [
        "TANK"    => "Tank",
        "HEATING" => "Heating element anode electrical parts"
    ];

    while ($row = $result->fetch_assoc()) {
        // map inside the loop
        $warranty_for   = $row['warranty_for'];
        $display_value  = $warranty_map[$warranty_for] ?? $warranty_for;

        echo "<tr>";
        echo "<th scope='row'>" . $count++ . "</th>";
        echo "<td>" . htmlspecialchars($row['invoice_no']) . "</td>";
        echo "<td>" . htmlspecialchars($row['invoice_date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['dealer_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['cus_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['item_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['warranty_period']) . "</td>";
        echo "<td>" . htmlspecialchars($display_value) . "</td>";  // <-- fixed
        echo "<td>" . htmlspecialchars($row['warranty_expiry_date']) . "</td>";

        // expiry highlight
        $expiryDate = $row['warranty_expiry_date'];
        $today = date('Y-m-d');
        if ($expiryDate < $today) {
            echo "<td style='color: red; font-weight: bold;'>Warranty Period is Expired (" . htmlspecialchars($expiryDate) . ")</td>";
        } else {
            echo "<td style='color: green; font-weight: bold;'>Warranty Period is Pending (" . htmlspecialchars($expiryDate) . ")</td>";
        }

        echo "<td>" . htmlspecialchars($row['qty']) . "</td>";
        echo "<td>" . htmlspecialchars($row['serial_no']) . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='9'>No warranty data found for this serial number.</td></tr>";
}
?>
