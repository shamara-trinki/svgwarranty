<?php
header('Content-Type: application/json');

include __DIR__ . '/../connection/db.php';  // Correct path

try {
    $invoice_no = $_POST['invoice_no'];
    $invoice_date = $_POST['invoice_date'];
    $dealer_id = $_POST['dealer_id'];
    $customer_id = $_POST['customer_id'];
    $warranty_period = $_POST['warranty_period'];
    $warranty_for = $_POST['warranty_for'];
    $warranty_expiry_date = $_POST['warranty_expiry_date'];
    $item_ids = $_POST['item_id'] ?? [];
    $qtys = $_POST['qty'] ?? [];
    $serials = $_POST['serial_id'] ?? [];

    $conn->begin_transaction();

foreach ($item_ids as $index => $item_id) {
    $qty = $qtys[$index] ?? 1;

    $stmt = $conn->prepare("INSERT INTO warranty (invoice_no, invoice_date, dealer_id, customer_id, item_id, qty, warranty_period, warranty_for, warranty_expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "ssiiiisss",
        $invoice_no,
        $invoice_date,
        $dealer_id,
        $customer_id,
        $item_id,
        $qty,
        $warranty_period,
        $warranty_for,
        $warranty_expiry_date
    );
    $stmt->execute();
    $warranty_id = $conn->insert_id;
    $stmt->close();

    // Insert serial numbers
    if (!empty($serials[$index])) {
        $stmt2 = $conn->prepare("INSERT INTO warranty_serials (warranty_id, serial_no) VALUES (?, ?)");
        foreach ($serials[$index] as $s) {
            $serial_no = trim($s);
            if ($serial_no !== '') {
                $stmt2->bind_param("is", $warranty_id, $serial_no);
                $stmt2->execute();
            }
        }
        $stmt2->close();
    }
}


    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Warranty added successfully!']);
} catch (mysqli_sql_exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
$conn->close();
exit;
?>
