<!-- Header -->
<?php
session_start();

include 'header.php';
include 'connection/db.php';



?>


<body>
    <div class="container-fluid mt-4">
        <!-- Navbar -->
        <?php include 'title.php';?>

        <!-- Customers Table -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-primary">👤 Customers</h5>
                        <button class="btn btn-primary btn-modern" data-bs-toggle="modal"
                            data-bs-target="#customerModal">➕ Add Customer</button>
                    </div>
                    <div class="table-responsive">
                        <table id="customerTable" class="table table-striped table-bordered nowrap align-middle">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Address Line 1</th>
                                    <th>Address Line 2</th>
                                    <th>Mobile No</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                        $sql = "SELECT
                                   *
                                FROM customer ORDER BY id DESC";

                        $result = $conn->query($sql);
                        $count = 1;

                        if ($result->num_rows > 0) {
                             while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<th scope='row'>{$count}</th>";
                                echo "<td>" . htmlspecialchars($row['cus_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['address_line1']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['address_line2']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['mobile_no']) . "</td>";

      echo "<td class='text-center'>
        <button class='btn btn-sm btn-primary editCustomerBtn'
            data-id='" . $row['id'] . "'
            data-name='" . htmlspecialchars($row['cus_name']) . "'
            data-mobile='" . htmlspecialchars($row['mobile_no']) . "'
            data-addr1='" . htmlspecialchars($row['address_line1']) . "'
            data-addr2='" . htmlspecialchars($row['address_line2']) . "'>
            <i class='fa fa-edit'></i>
        </button>
        <button class='btn btn-sm btn-danger deleteCustomerBtn'
            data-id='" . $row['id'] . "'>
            <i class='fa fa-trash'></i>
        </button>
    </td>";

                                echo "</tr>";
                                $count++;
                                }
                                } else {
                                echo "<tr>
                                    <td colspan='12' class='text-center'>No results found</td>
                                </tr>";
                                }

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Dealer & Item Tables side by side -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card shadow-sm p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-primary">🏢 Dealers</h5>
                        <button class="btn btn-success btn-modern" data-bs-toggle="modal"
                            data-bs-target="#dealerModal">➕ Add Dealer</button>
                    </div>
                    <div class="table-responsive">
                        <table id="dealerTable" class="table table-striped table-bordered nowrap align-middle">
                            <thead class="table-info text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Dealer Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                        $sql = "SELECT
                                   *
                                FROM dealer ORDER BY id DESC";

                        $result = $conn->query($sql);
                        $count = 1;

                        if ($result->num_rows > 0) {
                             while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<th scope='row'>{$count}</th>";
                                echo "<td>" . htmlspecialchars($row['dealer_name']) . "</td>";


                                echo "<td class='text-center'>
                                        <button class='btn btn-sm btn-primary updateDealerBtn'
                                            data-id='" . htmlspecialchars($row['id']) . "'
                                            data-dealer_name='" . htmlspecialchars($row['dealer_name']) . "'
                                           >
                                            <i class='fa fa-edit'></i>
                                        </button>
                                          <button class='btn btn-sm btn-danger deleteDealerBtn'
            data-id='" . $row['id'] . "'>
            <i class='fa fa-trash'></i>
        </button>
                                    </td>";
                                echo "</tr>";
                                $count++;
                            }
                        } else {
                            echo "<tr><td colspan='12' class='text-center'>No results found</td></tr>";
                        }

                        ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-primary">Items</h5>
                        <button class="btn btn-success btn-modern" data-bs-toggle="modal" data-bs-target="#itemModal">➕
                            Add Item</button>
                    </div>
                    <div class="table-responsive">
                        <table id="itemTable" class="table table-striped table-bordered nowrap align-middle">
                            <thead class="table-success text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Item Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                        $sql = "SELECT
                                   *
                                FROM item ORDER BY id DESC";

                        $result = $conn->query($sql);
                        $count = 1;

                        if ($result->num_rows > 0) {
                             while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<th scope='row'>{$count}</th>";
                                echo "<td>" . htmlspecialchars($row['item_name']) . "</td>";

                                echo "<td class='text-center'>
                                        <button class='btn btn-sm btn-primary editItemBtn'
                                            data-id='" . htmlspecialchars($row['id']) . "'
                                            data-item_name='" . htmlspecialchars($row['item_name']) . "'
                                            >
                                            <i class='fa fa-edit'></i>
                                        </button>
                                        <button class='btn btn-sm btn-danger deleteItemBtn'
            data-id='" . $row['id'] . "'>
            <i class='fa fa-trash'></i>
        </button>
                                    </td>";
                                echo "</tr>";
                                $count++;
                            }
                        } else {
                            echo "<tr><td colspan='12' class='text-center'>No results found</td></tr>";
                        }

                        ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Modals -->
    <!-- Customer Modal -->
    <div class="modal fade" id="customerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="customerModalTitle">Add Customer</h5>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="customer_id" name="customer_id">

                    <label class="form-label">Customer Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name"
                        placeholder="Customer Name">

                    <label class="form-label">Mobile No</label>
                    <input type="number" class="form-control" id="mobile_no" name="mobile_no" placeholder="07*******">

                    <label class="form-label">Address Line 1</label>
                    <input type="text" class="form-control" id="address_line1" placeholder="No 1234, Main St">

                    <label class="form-label">Address Line 2</label>
                    <input type="text" class="form-control" id="address_line2" placeholder="Colombo 10">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveCustomerBtn"
                        data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Dealer Modal -->
    <div class="modal fade" id="dealerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="dealerModalTitle">Add Dealer</h5>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="dealer_id" name="dealer_id" />
                    <label class="form-label">Dealer Name</label>
                    <input type="text" class="form-control" id="dealer_name" name="dealer_name"
                        placeholder="Dealer Name" />
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveDealerBtn"
                        data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Item Modal -->
    <div class="modal fade" id="itemModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="itemModalTitle">Add Item</h5>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="item_id" name="item_id">
                    <label class="form-label">Item Name</label>
                    <input type="text" class="form-control" id="item_name" name="item_name" placeholder="Item Name">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveItemBtn" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>



    <!-- Footer -->


    <script>
    // Dealer
    $(document).ready(function() {
        // Add Dealer button
        $(document).on("click", "#addDealerBtn", function() {
            $("#dealerModalTitle").text("Add Dealer");
            $("#dealer_id").val("");
            $("#dealer_name").val("");
            $("#saveDealerBtn").data("action", "add");
            $("#dealerModal").modal("show");
        });

        // Edit Dealer button
        $(document).on("click", ".updateDealerBtn", function() {
            let dealerId = $(this).data("id");
            let dealerName = $(this).data("dealer_name");

            $("#dealerModalTitle").text("Edit Dealer");
            $("#dealer_id").val(dealerId);
            $("#dealer_name").val(dealerName);
            $("#saveDealerBtn").data("action", "edit");
            $("#dealerModal").modal("show");
        });

        // Save button (Add/Edit)
        $("#saveDealerBtn").on("click", function() {
            let action = $(this).data("action");
            let dealerId = $("#dealer_id").val();
            let dealerName = $("#dealer_name").val();

            if (dealerName.trim() === "") {
                alert("Dealer name is required");
                return;
            }

            if (action === "add") {
                $.post("controller/dealerController.php", {
                    dealer_name: dealerName
                }, function(res) {
                    alert("Dealer added successfully!");
                    location.reload(); // or update table dynamically
                });
            } else if (action === "edit") {
                $.post("controller/dealerController.php", {
                    id: dealerId,
                    dealer_name: dealerName
                }, function(res) {
                    alert("Dealer updated successfully!");
                    location.reload(); // or update table dynamically
                });
            }
        });
    });

    // Item
    $(document).ready(function() {
        // Edit Item button
        $(document).on("click", ".editItemBtn", function() {
            let itemId = $(this).data("id");
            let itemName = $(this).data("item_name"); // match your data attribute

            $("#itemModalTitle").text("Edit Item");
            $("#item_id").val(itemId);
            $("#item_name").val(itemName);
            $("#saveItemBtn").data("action", "edit");
            $("#itemModal").modal("show");
        });

        // Save Item button (Add/Edit)
        $("#saveItemBtn").on("click", function() {
            let action = $(this).data("action");
            let itemId = $("#item_id").val();
            let itemName = $("#item_name").val().trim();

            if (itemName === "") {
                alert("Item name is required");
                return;
            }

            $.post("controller/itemController.php", {
                id: itemId,
                item_name: itemName
            }, function(res) {
                if (res.success) {
                    alert(res.message);
                    location.reload(); // or update table row dynamically
                } else {
                    alert(res.message);
                }
            }, "json");
        });
    });

    // Customer
    $(document).ready(function() {

        // Open modal for adding customer
        $(document).on("click", "#addCustomerBtn", function() {
            $("#customerModalTitle").text("Add Customer");
            $("#customer_id").val(""); // empty means new customer
            $("#customer_name").val("");
            $("#mobile_no").val("");
            $("#address_line1").val("");
            $("#address_line2").val("");
            $("#saveCustomerBtn").data("action", "save");
            $("#customerModal").modal("show");
        });

        // Open modal for editing customer
        $(document).on("click", ".editCustomerBtn", function() {
            let customerId = $(this).data("id");
            let customerName = $(this).data("name");
            let mobileNo = $(this).data("mobile");
            let addr1 = $(this).data("addr1");
            let addr2 = $(this).data("addr2");

            $("#customerModalTitle").text("Edit Customer");
            $("#customer_id").val(customerId);
            $("#customer_name").val(customerName);
            $("#mobile_no").val(mobileNo);
            $("#address_line1").val(addr1);
            $("#address_line2").val(addr2);
            $("#saveCustomerBtn").data("action", "save"); // same action for add/update
            $("#customerModal").modal("show");
        });

        // Save Customer (Add/Edit)
        $("#saveCustomerBtn").on("click", function() {
            let customerId = $("#customer_id").val();
            let customerName = $("#customer_name").val().trim();
            let mobileNo = $("#mobile_no").val().trim();
            let addr1 = $("#address_line1").val().trim();
            let addr2 = $("#address_line2").val().trim();

            if (customerName === "") {
                alert("Customer name is required");
                return;
            }

            $.post("controller/customerController.php", {
                customer_id: customerId, // send ID if editing
                customer_name: customerName,
                mobile_no: mobileNo,
                address_line1: addr1,
                address_line2: addr2
            }, function(res) {
                if (res.success) {
                    alert(res.message);
                    location.reload(); // or update table dynamically
                } else {
                    alert(res.message);
                }
            }, "json");
        });

    });



    $(document).on("click", ".deleteCustomerBtn", function() {
        let customerId = $(this).data("id");
        let row = $(this).closest("tr");

        if (confirm("Are you sure you want to delete this customer?")) {
            $.post("controller/delete_customer.php", {
                id: customerId
            }, function(res) {
                // Show browser alert
                alert(res.message);

                if (res.success) {
                    // Remove the row only if delete was successful
                    row.remove();
                }
            }, "json");
        }
    });

    $(document).on("click", ".deleteDealerBtn", function() {
        let dealerId = $(this).data("id");
        let row = $(this).closest("tr");

        if (confirm("Are you sure you want to delete this dealer?")) {
            $.post("controller/delete_dealer.php", {
                id: dealerId
            }, function(res) {
                // Show browser alert
                alert(res.message);

                if (res.success) {
                    // Remove the row only if delete was successful
                    row.remove();
                }
            }, "json");
        }
    });
    $(document).on("click", ".deleteItemBtn", function() {
        let itemId = $(this).data("id");
        let row = $(this).closest("tr");

        if (confirm("Are you sure you want to delete this item?")) {
            $.post("controller/delete_item.php", {
                id: itemId
            }, function(res) {
                // Show browser alert
                alert(res.message);

                if (res.success) {
                    // Remove the row only if delete was successful
                    row.remove();
                }
            }, "json");
        }
    });
    </script>
</body>

</html>
