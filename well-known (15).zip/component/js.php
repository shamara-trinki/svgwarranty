<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.formtowizard.js"></script>
<script>
new DataTable('#example', {
    layout: {
        topStart: {
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    }
});
$('#searchDealerWise').on('click', function(e) {
    e.preventDefault();

    var start_date = $('#start_date').val();
    var end_date = $('#end_date').val();
    var dealer = $('#dealer').val();

    if (!start_date || !end_date) {
        alert("Please select Start Date and End Date.");
        return;
    }

    $.ajax({
        url: 'controller/searchDealerWiseController.php',
        type: 'POST',
        data: {
            start_date: start_date,
            end_date: end_date,
            dealer: dealer
        },
        success: function(response) {
            // Destroy existing DataTable if initialized
            if ($.fn.DataTable.isDataTable('#example')) {
                $('#example').DataTable().clear().destroy();
            }

            // Fill tbody with returned rows
            $('#warrantyTableDealerBody').html(response);

            // Initialize DataTable with export buttons
            new DataTable('#example', {
                responsive: true,
                layout: {
                    topStart: {
                        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                    }
                }
            });
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
            alert("Error fetching data.");
        }
    });
});

document.addEventListener("DOMContentLoaded", function() {
    fetch("controller/get_dealer.php")
        .then(res => res.json())
        .then(dealer => {
            const select = document.getElementById("dealer_id");
            dealer.forEach(dealer => {
                const opt = document.createElement("option");
                opt.value = dealer.id;
                opt.textContent = dealer.dealer_name;
                select.appendChild(opt);
            });
        })
        .catch(err => console.error("Failed to load dealer", err));

});
</script>
