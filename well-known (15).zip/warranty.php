<!-- Header -->
<?php
session_start();

include 'header.php';
include 'connection/db.php';

?>


<body class="p-2">
    <div class="container">

        <!-- Navbar -->
        <?php include 'title.php';?>

        <form id="SignupForm" action="" class="agile_form" method="post">
            <!-- Invoice Details -->
            <div class="card mb-4">
                <div class="card-header">📑 Invoice Details</div>
                <div class="card-body row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Invoice No</label>
                        <input id="invoice_no" type="text" name="invoice_no" class="form-control" required />
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Invoice Date</label>
                        <input id="invoice_date" type="date" name="invoice_date" class="form-control" required />
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Dealer</label>
                        <div class="input-group">
                            <select id="dealer_id" name="dealer_id" class="form-select" style="flex: 2;">
                                <option value="">Select Dealer</option>

                            </select>
                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                data-bs-target="#dealerModal">+ Add</button>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>Item Details</span>
                    <button type="button" class="btn btn-success btn-sm" id="addRow">+ Add Item</button>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-hover align-middle" id="itemsTable">
                        <thead class="table-light">
                            <tr>
                                <th>Item</th>
                                <th style="width: 120px;">Quantity</th>
                                <th style="width: 300px;">Serial Nos</th>
                                <th style="width: 80px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Initially empty -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Customer Section -->
            <div class="card mb-4">
                <div class="card-header">👤 Customer Details</div>
                <div class="card-body">
                    <div class="input-group">
                        <select id="customer_id" name="customer_id" class="form-select" style="flex: 2;">
                            <option value="">Select Customer</option>
                        </select>
                        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                            data-bs-target="#customerModal">
                            + Add Customer
                        </button>
                    </div>
                </div>
            </div>


            <!-- Warranty -->
            <div class="card mb-4">
                <div class="card-header">🛡️ Warranty Details</div>
                <div class="card-body row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Warranty Period</label>
                        <select name="warranty_period" id="warranty_period" class="form-select" required>
                            <!-- <option value="">-- Select --</option> -->
                            <option value="2">2 Years</option>
                            <option value="5">5 Years</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Warranty For</label>
                        <select name="warranty_for" id="warranty_for" class="form-select" required>
                            <!-- <option value="">-- Select --</option> -->
                            <option value="TANK">Tank </option>
                            <option value="HEATING">Heating element anode electrical parts</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php
                              $rawDate = $record['warranty_expiry_date'] ?? '';
                          $formattedDate = '';

                            if ($rawDate) {
                               $date = date_create($rawDate);
                               if ($date) {
                                   $formattedDate = date_format($date, 'Y-m-d');
                                 }
                            }
                       ?>
                        <label class="form-label">Warranty Expiry Date</label>
                        <input type="date" name="warranty_expiry_date" id="update_warranty_expiry_date"
                            class="form-control">
                    </div>
                </div>
            </div>




            <!-- Customer Modal -->
            <div class="modal fade" id="customerModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Customer</h5>
                        </div>
                        <div class="modal-body">
                            <label class="form-label">Customer Name</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name"
                                placeholder="Customer Name" />


                            <label class="form-label">Mobile No</label>
                            <input type="number" class="form-control" id="mobile_no" name="mobile_no"
                                placeholder="07*******">
                            <label class="form-label">Address Line 1</label>
                            <input type="text" class="form-control" id="address_line1" placeholder="No 1234 ,Main St">

                            <label class="form-label">Address Line 2</label>
                            <input type="text" class="form-control" id="address_line2" placeholder="Colombo 10">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="saveCustomerBtn"
                                data-bs-dismiss="modal">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dealer Modal -->
            <div class="modal fade" id="dealerModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Dealer</h5>
                        </div>
                        <div class="modal-body">
                            <label class="form-label">Dealer Name</label>
                            <input type="text" class="form-control" id="dealer_name" name="dealer_name"
                                placeholder="New Dealer Name" />
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="saveDealerBtn"
                                data-bs-dismiss="modal">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Item Modal -->
            <div class="modal fade" id="itemModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Item</h5>
                        </div>
                        <div class="modal-body">
                            <label class="form-label">Item Name</label>
                            <input type="text" class="form-control" id="item_name" name="item_name"
                                placeholder="New Item Name">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="saveItemBtn"
                                data-bs-dismiss="modal">Save</button>
                        </div>
                    </div>
                </div>
            </div>


            <div class="text-end pb-5">
                <button type="submit" class="btn btn-primary px-5 agileinfo_primary submit" id="SaveAccount">💾 Save
                    Warranty</button>
            </div>

        </form>

    </div>

</body>
<?php include 'footer.php';?>

<script>
$(document).ready(function() {

    let itemsList = [];

    // Fetch items from backend
    function loadItems(callback) {
        fetch("controller/get_item.php")
            .then(res => res.json())
            .then(data => {
                itemsList = data;
                if (callback) callback();
            });
    }
    loadItems();

    // Populate item select
    function populateItemSelect(select) {
        select.empty();
        select.append('<option value="">-- Select Item --</option>');
        itemsList.forEach(item => {
            select.append(`<option value="${item.id}">${item.item_name}</option>`);
        });
    }

    // Populate all selects (when new item added)
    function refreshAllSelects() {
        $(".item-select").each(function() {
            populateItemSelect($(this));
        });
    }

    // Add new row
    $('#addRow').click(function() {
        const rowIndex = $('#itemsTable tbody tr').length;
        const newRow = $(`
            <tr>
                <td>
                    <div class="input-group">
                        <select name="item_id[]" class="form-select item-select" required></select>
                        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#itemModal">+ Add</button>
                    </div>
                </td>
                <td>
                    <input type="number" name="qty[]" class="form-control quantity" min="1" value="1" required>
                </td>
                <td>
                    <div class="serial-container"></div>
                </td>
                <td>
                    <button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>
                </td>
            </tr>
        `);

        $('#itemsTable tbody').append(newRow);

        const select = newRow.find('.item-select');
        populateItemSelect(select);

        // Initialize serials
        updateSerialFields(newRow, 1, rowIndex);
    });

    // Remove row
    $('#itemsTable').on('click', '.removeRow', function() {
        $(this).closest('tr').remove();
        updateAllSerialNames();
    });

    // Update serials when quantity changes
    $('#itemsTable').on('input', '.quantity', function() {
        const row = $(this).closest('tr');
        const qty = parseInt($(this).val()) || 1;
        const rowIndex = $('#itemsTable tbody tr').index(row);
        updateSerialFields(row, qty, rowIndex);
    });

    // Function to create serial input fields
    function updateSerialFields(row, qty, rowIndex) {
        const serialContainer = $(row).find('.serial-container');
        serialContainer.empty();
        for (let i = 0; i < qty; i++) {
            serialContainer.append(
                `<input type="text" name="serial_id[${rowIndex}][]" class="form-control mb-1" placeholder="Serial No ${i + 1}">`
            );
        }
    }

    // After removing row, fix serial_id names to match current row index
    function updateAllSerialNames() {
        $('#itemsTable tbody tr').each(function(index) {
            const row = $(this);
            const qty = parseInt(row.find('.quantity').val()) || 1;
            updateSerialFields(row, qty, index);
        });
    }

    function calculateExpiry() {
        const invoiceDate = $('#invoice_date').val();
        const warrantyPeriod = $('#warranty_period').val();
        const warrantyYears = parseInt(warrantyPeriod);

        if (invoiceDate && warrantyYears) {
            const date = new Date(invoiceDate);
            date.setFullYear(date.getFullYear() + warrantyYears);

            const yyyy = date.getFullYear();
            const mm = String(date.getMonth() + 1).padStart(2, '0');
            const dd = String(date.getDate()).padStart(2, '0');
            const formatted = `${yyyy}-${mm}-${dd}`;

            $('#update_warranty_expiry_date').val(formatted);
        } else {
            $('#update_warranty_expiry_date').val('');
        }
    }

    $('#invoice_date, #warranty_period').on('change', calculateExpiry);

    // ==========================
    // Handle item add from modal
    // ==========================
    $('#saveItemBtn').on('click', function() {
        const name = $('#item_name').val().trim();

        if (!name) {
            alert("Please enter Item Name");
            return;
        }

        $.post("controller/itemController.php", {
            item_name: name
        }, function(response) {
            if (response.success) {
                // ✅ Refresh items
                loadItems();

                // ✅ Repopulate all item selects with updated list
                setTimeout(() => {
                    $('.item-select').each(function() {
                        populateItemSelect($(this));
                    });

                    // Optionally auto-select the newly added item
                    $('.item-select:last').val(response.item_id);
                }, 300);

                $('#itemModal').modal('hide');
                $('#item_name').val('');
            } else {
                alert(response.message || "Failed to save item");
            }
        }, 'json');
    });
});


// $(document).ready(function() {
//     function calculateExpiry() {
//         const invoiceDate = $('#invoice_date').val();
//         const warrantyYears = parseInt($('#update_warranty_period').val());

//         if (invoiceDate && warrantyYears) {
//             const date = new Date(invoiceDate);
//             date.setFullYear(date.getFullYear() + warrantyYears);

//             // Format date as YYYY-MM-DD
//             const yyyy = date.getFullYear();
//             const mm = String(date.getMonth() + 1).padStart(2, '0');
//             const dd = String(date.getDate()).padStart(2, '0');
//             const formatted = `${yyyy}-${mm}-${dd}`;

//             $('#update_warranty_expiry_date').val(formatted);
//         } else {
//             $('#update_warranty_expiry_date').val('');
//         }
//     }

//     // Trigger when invoice date or warranty period changes
//     $('#invoice_date, #update_warranty_period').on('change', calculateExpiry);
// });
</script>
