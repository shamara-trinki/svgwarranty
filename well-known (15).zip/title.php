 <div class="main-header d-flex justify-content-between align-items-center">
     <img src="images/full-rain-logo.png" alt="Logo">
     <div class="text-center flex-grow-1">
         <h1>Woo Sun Eco Homes (Pvt) Ltd</h1>
         <h2>Warranty Tracker System</h2>
     </div>
     <h2>Welcome, <?php echo $_SESSION['username']; ?> </h2>
     <div class="m-2">
         <a href="logout.php" class="m-1"><i class="fa-solid fa-power-off" style="color: white;"></i> </a>
         <a href="register.php"><i class="fa fa-user-plus" style="color: white;"></i> </a>
     </div>

 </div>
